# CV metrics (computed from `results/`)

## Headline

| Metric | Value |
|---|---:|
| Base exact tool-call accuracy | 37.9% |
| Reliable Tool-SFT exact tool-call accuracy | 89.4% |
| Absolute improvement | 51.5% |
| Relative improvement | +136.0% |
| Held-out (unseen) function accuracy | 97.0% |
| Base false tool-call rate | 22.5% |
| Reliable Tool-SFT false tool-call rate | 57.5% |
| Absolute reduction in false tool calls | 35.0% |

## Full comparison

| Metric | Base | Tool-SFT | Reliable Tool-SFT |
|---|---:|---:|---:|
| Exact tool-call match | 37.9% | 100.0% | 89.4% |
| Function-name accuracy | 37.9% | 100.0% | 89.4% |
| Argument accuracy | 37.9% | 100.0% | 89.4% |
| JSON validity | 100.0% | 100.0% | 100.0% |
| Held-out function EM | 51.5% | 100.0% | 97.0% |
| When2Call decision accuracy | 75.6% | 25.0% | 36.9% |
| When2Call false tool-call rate | 22.5% | 66.7% | 57.5% |
| Missing-info accuracy | 70.0% | 0.0% | 22.5% |

| Count | Base | Tool-SFT | Reliable Tool-SFT |
|---|---:|---:|---:|
| Tool-call eval examples | 99 | 99 | 99 |
| When2Call eval examples | 160 | 160 | 160 |

---

Numbers are read directly from `results/*.json`. Fill in GPU model, wall-clock training time and peak memory from your own run log — those are not recorded by these scripts.
